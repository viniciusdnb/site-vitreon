<?php
    namespace site\Vitreon\Controller;
    use site\Vitreon\Router\RouterController;

    class ProdutosController extends RouterController{
        function index(){
            $this->render("produtos/index");
        }
    }

?>