<main class="container-fluid">
    <section class="row" style="padding: 20px; gap: 1rem;">
        <div class="col-md-4" style=" padding: 10px; width: 350px; border-radius: 5px; box-shadow: 0 0 5px 0 rgb(142, 142, 143);">
            <div class="row text-center">
                <div class="col">
                    <a href="/img/_CGF8313.png" target="_blank">
                        <img src="/img/_CGF8313.png" style="width: 224px;" alt="" sizes="" srcset="">
                    </a>
                </div>
            </div>
            <div class="row">
                <p>REFERENCIA AW 2412</p>
            </div>
            <div class="row">
                <div class="col"><span>Peso</span></div>
                <div class="col text-end"><span>206g</span></div>
            </div>
            <div class="row">
                <div class="col"><span>Dimensoes</span></div>
                <div class="col text-end"><span>57,1 x 149,2mm</span></div>
            </div>
            <div class="row">
                <div class="col"><span>Volume total</span></div>
                <div class="col text-end"><span>245ml</span></div>
            </div>
            <div class="row">
                <div class="col"><span>volume util</span></div>
                <div class="col text-end"><span>230ml</span></div>
            </div>
        </div>
        <div class="col-md-4" style=" padding: 10px; width: 350px; border-radius: 5px; box-shadow: 0 0 5px 0 rgb(142, 142, 143);">
            <div class="row text-center">
                <div class="col">
                    <a href="/img/_CGF8313.png" target="_blank">
                        <img src="/img/_CGF8313.png" style="width: 224px;" alt="" sizes="" srcset="">
                    </a>
                </div>
            </div>
            <div class="row">
                <p>REFERENCIA AW 2412</p>
            </div>
            <div class="row">
                <div class="col"><span>Peso</span></div>
                <div class="col text-end"><span>206g</span></div>
            </div>
            <div class="row">
                <div class="col"><span>Dimensoes</span></div>
                <div class="col text-end"><span>57,1 x 149,2mm</span></div>
            </div>
            <div class="row">
                <div class="col"><span>Volume total</span></div>
                <div class="col text-end"><span>245ml</span></div>
            </div>
            <div class="row">
                <div class="col"><span>volume util</span></div>
                <div class="col text-end"><span>230ml</span></div>
            </div>
        </div>
    </section>
</main>

<div id="up">
    <a href="<?php echo LINK ?>produtos/#produtos" class="p-4">
        <img id="img_footer" src="<?php echo LINK ?>public/img/double-up-64.png" alt="" srcset="">
    </a>
</div>