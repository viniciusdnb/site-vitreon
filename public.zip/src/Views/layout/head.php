<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo LINK; ?>public/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo LINK; ?>public/css/vitreon.css">
    <script src="<?php echo LINK ?>public/js/bootstrap.min.js"></script>
    <link rel="shortcut icon" href="<?php echo LINK ?>public/img/logo160.png" type="image/x-icon">
    <title>Vitreon</title>
</head>

<body>