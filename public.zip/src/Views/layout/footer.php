<div id="whats">
    <a href="https://wa.me/5511914856039?text=ola! tenho interesse nos produtos" target="_blank" class="p-4">
        <img id="img_footer" src="<?php echo LINK ?>public/img/whatsapp-96.png" alt="" srcset="">
    </a>
</div>



<footer class="container-fluid p-3">
    <div class="row text-center">
        <div class="col">
            <img src="<?php echo LINK ?>public/img/logo160-removebg.png" width="50px" alt="logo vitreon">
        </div>
        <div class="col">
            <p class="text-black">2025 © - Todos os direitos reservados</p>
        </div>
    </div>
</footer>
</body>
</html>