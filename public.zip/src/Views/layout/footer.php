<div id="whats">
    <a href="https://wa.me/5511914856039?text=ola! tenho interesse nos produtos" target="_blank" class="p-4" rel="noopener noreferrer" decoding="async"
loading="lazy">
        <img id="img_footer" src="<?php echo LINK ?>public/img/whatsapp-96.png" alt="icone do whatsapp">
    </a>
</div>



<footer class="container-fluid p-3">
    <div class="row text-center">
        <div class="col">
            <img src="<?php echo LINK ?>public/img/logo160-removebg.png" width="50px" alt="logo vitreon">
        </div>
        <div class="col">
            <p class="text-black">2025 © Vitreon — Frascos de Vidro e Válvulas para Perfumaria</p>
        </div>
    </div>
</footer>
    <script src="<?php echo LINK ?>public/js/popper.min.js" defer></script>
    <script src="<?php echo LINK ?>public/js/bootstrap.min.js" defer></script>
</body>
</html>