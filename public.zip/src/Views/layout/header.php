<header id="inicio" class="container-fluid text-center border-bottom rounded-bottom">
    <nav class="navbar p-4 navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="<?php echo LINK ?>public/img/logo160-removebg.png" width="50px" alt="logo vitreon">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link " href="<?php echo LINK ?>">INICIO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo LINK ?>produtos">PRODUTOS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo LINK ?>#sobre">SOBRE</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo LINK ?>#contato" class="nav-link">CONTATO</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>