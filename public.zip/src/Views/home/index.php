<main>
    <section class="container-fluid" id="section_principal">
        <div class="row">
            <div class="col-md-6">
                <div id="carrousel-principal" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="<?php echo LINK ?>public/img/_CGF8313.png" class="d-block w-100" alt="...">
                        </div>
                        <!--<div class="carousel-item">
                                <img src="/img/GridArt_20251017_131502405.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="/img/GridArt_20251017_131602967.jpg" class="d-block w-100" alt="...">
                            </div>
                            <div class="carousel-item">
                                <img src="/img/Sem título.png" class="d-block w-100" alt="...">
                            </div>-->
                    </div>

                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <h1 class="text-light  p-5">VIDROS PARA O SEU PROJETO É COM A VITREON</h1>
                    <p class="text-light gy-5 p-5">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nihil
                        natus
                        vero iste animi aperiam qui
                        provident minus? Nisi, officia, repudiandae, natus minus in architecto illum enim corrupti
                        perspiciatis suscipit quasi?</p>
                    <div class="p-5">
                        <a href="/produtos.html" class="gy-5 col-6" id="btn-catalogo">VEJA NOSSOS PRODUTOS</a>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section id="sobre" class="container-fluid p-5">
        <div class="row">
            <div class="col-md-3">
                <div class="row">
                    <img class="img-detalhes" src="<?php echo LINK ?>public/img/building.svg" alt="" srcset="">
                </div>
                <div class="row">
                    <h2 class="sizeSubTitle">VENDA</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam blanditiis impedit
                        expedita corrupti quibusdam et nobis ipsam enim ipsa commodi molestias, illo nemo reiciendis
                        voluptatibus facere, tempore natus porro. Debitis!</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="row">
                    <img class="img-detalhes" src="<?php echo LINK ?>public/img/blog.svg" alt="" srcset="">
                </div>
                <div class="row">
                    <h3 class="sizeSubTitle">COMERCIO</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam blanditiis impedit
                        expedita corrupti quibusdam et nobis ipsam enim ipsa commodi molestias, illo nemo reiciendis
                        voluptatibus facere, tempore natus porro. Debitis!</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="row">
                    <img class="img-detalhes" src="<?php echo LINK ?>public/img/portfolio.svg" alt="" srcset="">
                </div>
                <div class="row">
                    <h4 class="sizeSubTitle">LOCAL</h4>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam blanditiis impedit
                        expedita corrupti quibusdam et nobis ipsam enim ipsa commodi molestias, illo nemo reiciendis
                        voluptatibus facere, tempore natus porro. Debitis!</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="row">
                    <img class="img-detalhes" src="<?php echo LINK ?>public/img/shopping-bag.svg" alt="" srcset="">
                </div>
                <div class="row">
                    <h5 class="sizeSubTitle">ENTREGA</h5>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam blanditiis impedit
                        expedita corrupti quibusdam et nobis ipsam enim ipsa commodi molestias, illo nemo reiciendis
                        voluptatibus facere, tempore natus porro. Debitis!</p>
                </div>
            </div>
        </div>
    </section>
    <section id="contato" class="p-4">
        <div class="row">
            <div class="row">
                <p class="text-light" style="font-size: 48px;">CONTATO E LOCALIZAÇÃO</p>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="row text-center p-4">
                        <img id="img_footer" style="margin-left: 44%;" src="<?php echo LINK ?>public/img/location-64.png" alt="" srcset="">
                        <p class="text-light p-4  sizeParagraphContato">
                            R. Antônio Saviano, 245 -
                            Vila Pindorama, Barueri - SP, 06413-205
                        </p>
                    </div>
                    <div class="row" style="border-radius: 5px;">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1081.472818687176!2d-46.8796582367997!3d-23.489108342117582!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cf03a34e8f37c3%3A0x550eacc274ae1cfa!2sR.%20Ant%C3%B4nio%20Saviano%2C%20245%20-%20Vila%20Pindorama%2C%20Barueri%20-%20SP%2C%2006413-205!5e1!3m2!1spt-BR!2sbr!4v1760968859969!5m2!1spt-BR!2sbr"
                            width="250" height="250" style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                    <div class="row p-3">
                        <img id="img_footer" class="p-3" style="margin-left: 44%;" src="<?php echo LINK ?>public/img/whatsapp-64.png" alt=""
                            srcset="">
                        <a class="link-contato sizeParagraphContato"
                            href="https://wa.me/5511914856039?text=ola! tenho interesse nos produtos" target="_blank"
                            class="p-4">(11) 9.1485-6039</a>
                    </div>
                    <div class="row p-3">
                        <img id="img_footer" class="p-3" style="margin-left: 44%;" src="<?php echo LINK ?>public/img/gmail-logo-64.png" alt=""
                            srcset="">
                        <a class="link-contato sizeParagraphContato" href="mailto:felipe@decorgroupbrasil.com.br"
                            class="p-4">felipe@decorgroupbrasil.com.br</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<div id="up">
    <a href="<?php echo LINK ?>#inicio" class="p-4">
        <img id="img_footer" src="<?php echo LINK ?>public/img/double-up-64.png" alt="" srcset="">
    </a>
</div>