<?php

    require_once __DIR__ . "/vendor/autoload.php";

    use site\Vitreon\Router\Start;

    $start = new Start;

?>